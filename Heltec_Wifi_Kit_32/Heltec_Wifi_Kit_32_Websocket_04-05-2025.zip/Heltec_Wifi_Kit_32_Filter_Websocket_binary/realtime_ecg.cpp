#include "realtime_ecg.h"
#include <math.h>

RealtimeECGProcessor::RealtimeECGProcessor(uint16_t fs) : fs(fs) {
  //windowSize = round(0.2f * fs);         // 200 ms
  windowSize = round(0.05f * fs);         // 200 ms
  inhibitTime = round(0.05f * fs);       // 50 ms
  maxWindowSize = round(2.0f * fs);      // 2 s

  sum_val = 0;
  bufferIndex = 0;
  maxIndex = 0;
  filterDisabled = false;
  inhibitCounter = 0;
  last_r_peak_time = 0;
  prev_r_peak_time = 0;
  bpm = 0;
  newBPMFlag = false;

  for (int i = 0; i < ECG_BUFFER_MAX; i++) maxBuffer[i] = 0;
  for (int i = 0; i < 100; i++) movAvgBuffer[i] = 0;
}

float RealtimeECGProcessor::processSample(float sample, uint32_t timestamp) {
  maxBuffer[maxIndex] = sample;
  maxIndex = (maxIndex + 1) % maxWindowSize;

  // max-Wert berechnen mit abs um R-Zacke in beide Richtungen zu erkennen
  float maxVal = fabs(maxBuffer[0]);
  for (int i = 1; i < maxWindowSize; i++) {
    float val = fabs(maxBuffer[i]);
    if (val > maxVal) maxVal = val;
  }
  dynamicThreshold = 0.5f * maxVal;

  // R-Zacken-Erkennung
  if (fabs(sample) > dynamicThreshold && (timestamp - last_r_peak_time) > 300) {
    prev_r_peak_time = last_r_peak_time;
    last_r_peak_time = timestamp;

    if (prev_r_peak_time > 0) {
      uint32_t rr_interval = last_r_peak_time - prev_r_peak_time;
      bpm = round(60000.0f / rr_interval);
      newBPMFlag = true;
    }

    filterDisabled = true;
    inhibitCounter = inhibitTime;
  }

  // Inhibit-Zeit zählen
  if (filterDisabled && inhibitCounter > 0) {
    inhibitCounter--;
  } else {
    filterDisabled = false;
  }

  // Mittelwertfilter
  if (!filterDisabled) {
    sum_val = sum_val - movAvgBuffer[bufferIndex] + sample;
    movAvgBuffer[bufferIndex] = sample;
    bufferIndex = (bufferIndex + 1) % windowSize;
    return sum_val / windowSize;
  } else {
    return sample; // ungefiltert weitergeben
  }
}

bool RealtimeECGProcessor::isNewBPM() {
  return newBPMFlag;
}

int RealtimeECGProcessor::getBPM() {
  newBPMFlag = false;
  return bpm;
}
