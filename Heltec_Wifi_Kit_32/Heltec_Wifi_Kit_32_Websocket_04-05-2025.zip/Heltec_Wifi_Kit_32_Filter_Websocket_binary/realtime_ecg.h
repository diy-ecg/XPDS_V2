#ifndef REALTIME_ECG_H
#define REALTIME_ECG_H
#include <Arduino.h> 
#define ECG_BUFFER_MAX 400  // 2 Sekunden bei 200 Hz

class RealtimeECGProcessor {
public:
  RealtimeECGProcessor(uint16_t fs);

  float processSample(float sample, uint32_t timestamp);
  bool isNewBPM();
  int getBPM();

private:
  float maxBuffer[ECG_BUFFER_MAX];
  uint16_t maxIndex, maxWindowSize;
  float dynamicThreshold;

  float movAvgBuffer[100];
  float sum_val;
  uint16_t bufferIndex, windowSize;

  bool filterDisabled;
  int inhibitCounter;
  int inhibitTime;

  uint32_t last_r_peak_time;
  uint32_t prev_r_peak_time;
  int bpm;
  bool newBPMFlag;
  uint16_t fs;
};

#endif
