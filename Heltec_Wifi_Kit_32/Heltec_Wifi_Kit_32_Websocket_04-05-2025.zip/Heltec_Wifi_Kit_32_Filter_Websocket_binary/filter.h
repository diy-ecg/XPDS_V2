#ifndef FILTER_H
#define FILTER_H

#define PI 3.14159265358979323846f

struct IIRCoeffs {
  float b0, b1, b2, a1, a2;
};

enum FilterType { LOWPASS, HIGHPASS };

class IIRFilter {
  public:
    IIRFilter(float b0, float b1, float b2, float a1, float a2);
    float process(float x);
    void reset();

  private:
    float b0, b1, b2, a1, a2;
    float x1, x2, y1, y2;
};

// Funktionsprototypen
IIRCoeffs computeButterworthCoeffs(FilterType type, float cutoffFreqHz, float sampleRateHz);
IIRCoeffs computeNotchCoeffs(float f0, float fs, float Q);

#endif
