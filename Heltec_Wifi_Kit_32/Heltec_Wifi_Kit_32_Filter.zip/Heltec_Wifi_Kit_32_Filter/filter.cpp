#include "filter.h"
#include <math.h>

IIRFilter::IIRFilter(float b0, float b1, float b2, float a1, float a2)
  : b0(b0), b1(b1), b2(b2), a1(a1), a2(a2), x1(0), x2(0), y1(0), y2(0) {}

float IIRFilter::process(float x) {
  float y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
  x2 = x1; x1 = x;
  y2 = y1; y1 = y;
  return y;
}

void IIRFilter::reset() {
  x1 = x2 = y1 = y2 = 0;
}

IIRCoeffs computeButterworthCoeffs(FilterType type, float cutoffFreqHz, float sampleRateHz) {
  float omega = 2.0f * PI * cutoffFreqHz / sampleRateHz;
  float tan_omega = tanf(omega);

  float norm;
  IIRCoeffs coeffs;

  if (type == LOWPASS) {
    norm = 1.0f / (1.0f + sqrtf(2.0f) * tan_omega + tan_omega * tan_omega);
    coeffs.b0 = tan_omega * tan_omega * norm;
    coeffs.b1 = 2.0f * coeffs.b0;
    coeffs.b2 = coeffs.b0;
  } else if (type == HIGHPASS) {
    norm = 1.0f / (1.0f + sqrtf(2.0f) * tan_omega + tan_omega * tan_omega);
    coeffs.b0 = 1.0f * norm;
    coeffs.b1 = -2.0f * coeffs.b0;
    coeffs.b2 = coeffs.b0;
  }

  coeffs.a1 = 2.0f * (tan_omega * tan_omega - 1.0f) * norm;
  coeffs.a2 = (1.0f - sqrtf(2.0f) * tan_omega + tan_omega * tan_omega) * norm;

  return coeffs;
}

IIRCoeffs computeNotchCoeffs(float f0, float fs, float Q) {
  IIRCoeffs coeffs;

  float omega = 2.0f * PI * f0 / fs;
  float alpha = sinf(omega) / (2.0f * Q);

  float b0 =  1.0f;
  float b1 = -2.0f * cosf(omega);
  float b2 =  1.0f;
  float a0 =  1.0f + alpha;
  float a1 = -2.0f * cosf(omega);
  float a2 =  1.0f - alpha;

  coeffs.b0 = b0 / a0;
  coeffs.b1 = b1 / a0;
  coeffs.b2 = b2 / a0;
  coeffs.a1 = a1 / a0;
  coeffs.a2 = a2 / a0;

  return coeffs;
}
